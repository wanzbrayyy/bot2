import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import { StoreProvider } from '@/contexts/StoreContext';
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import StorePage from '@/pages/StorePage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import CheckoutPage from '@/pages/CheckoutPage';
import UserDashboard from '@/pages/UserDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import ProtectedRoute from '@/components/ProtectedRoute';
import MainLayout from '@/components/MainLayout';
import PaymentResultPage from '@/pages/PaymentResultPage';
import SellerRegistrationPage from '@/pages/SellerRegistrationPage';
import LiveChatWidget from '@/components/LiveChatWidget';

const RouteChangeTracker = () => {
  const location = useLocation();

  useEffect(() => {
    NProgress.start();
    NProgress.done();
  }, [location.pathname]);

  return null;
};

function App() {
  useEffect(() => {
    NProgress.configure({ 
      showSpinner: true,
      template: '<div class="bar" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon fas fa-sync-alt fa-spin"></div></div>'
    });
  }, []);

  return (
    <AuthProvider>
      <StoreProvider>
        <Router>
          <RouteChangeTracker />
          <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 text-white">
            <Helmet>
              <title>wanzofc shop - Your Digital Marketplace</title>
              <meta name="description" content="Temukan source code, aplikasi premium, dan bot terbaik di wanzofc shop. Jadilah seller dan raih keuntungan." />
            </Helmet>
            
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/seller-registration" element={
                <ProtectedRoute>
                  <SellerRegistrationPage />
                </ProtectedRoute>
              } />
              
              <Route element={<MainLayout />}>
                <Route path="/store" element={<StorePage />} />
                <Route path="/product/:slug" element={<ProductDetailPage />} />
                <Route path="/checkout/:id" element={
                  <ProtectedRoute>
                    <CheckoutPage />
                  </ProtectedRoute>
                } />
                <Route path="/payment-result" element={
                  <ProtectedRoute>
                    <PaymentResultPage />
                  </ProtectedRoute>
                } />
                <Route path="/dashboard" element={
                  <ProtectedRoute>
                    <UserDashboard />
                  </ProtectedRoute>
                } />
                <Route path="/admin" element={
                  <ProtectedRoute adminOnly>
                    <AdminDashboard />
                  </ProtectedRoute>
                } />
              </Route>
            </Routes>
            
            <Toaster />
            <LiveChatWidget />
          </div>
        </Router>
      </StoreProvider>
    </AuthProvider>
  );
}

export default App;