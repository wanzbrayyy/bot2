import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Navbar from '@/components/Navbar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import AdminStats from '@/components/admin/AdminStats';
import ProductTab from '@/components/admin/ProductTab';
import PromoTab from '@/components/admin/PromoTab';
import BroadcastTab from '@/components/admin/BroadcastTab';
import OrdersTab from '@/components/admin/OrdersTab';

const AdminDashboard = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <Helmet>
        <title>Admin Dashboard - Premium Store</title>
        <meta name="description" content="Dashboard admin Premium Store - Kelola produk, promo, dan broadcast" />
      </Helmet>
      
      <Navbar />

      <div className="pt-24 pb-12 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Admin Dashboard 👑
            </h1>
            <p className="text-xl text-white/70">
              Selamat datang, {user.name}! Kelola store Anda dengan mudah
            </p>
          </motion.div>

          <AdminStats />

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Tabs defaultValue="products" className="space-y-6">
              <TabsList className="glass-effect bg-white/10 border-white/20">
                <TabsTrigger value="products" className="data-[state=active]:bg-purple-500">
                  <i className="fas fa-box mr-2"></i>Produk
                </TabsTrigger>
                <TabsTrigger value="promo" className="data-[state=active]:bg-purple-500">
                  <i className="fas fa-tag mr-2"></i>Promo
                </TabsTrigger>
                <TabsTrigger value="broadcast" className="data-[state=active]:bg-purple-500">
                  <i className="fas fa-bullhorn mr-2"></i>Broadcast
                </TabsTrigger>
                <TabsTrigger value="orders" className="data-[state=active]:bg-purple-500">
                  <i className="fas fa-shopping-cart mr-2"></i>Pesanan
                </TabsTrigger>
              </TabsList>

              <TabsContent value="products">
                <ProductTab />
              </TabsContent>
              <TabsContent value="promo">
                <PromoTab />
              </TabsContent>
              <TabsContent value="broadcast">
                <BroadcastTab />
              </TabsContent>
              <TabsContent value="orders">
                <OrdersTab />
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;