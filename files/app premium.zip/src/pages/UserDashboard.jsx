import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Download, Bell, User, ShoppingBag, Star, Calendar } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const UserDashboard = ({ user, notifications, setNotifications }) => {
  const [purchases, setPurchases] = useState([]);
  const [stats, setStats] = useState({
    totalPurchases: 0,
    totalSpent: 0,
    unreadNotifications: 0
  });

  useEffect(() => {
    // Load user purchases
    const allPurchases = JSON.parse(localStorage.getItem('purchases') || '[]');
    const userPurchases = allPurchases.filter(p => p.userId === user.id);
    setPurchases(userPurchases);

    // Calculate stats
    const totalSpent = userPurchases.reduce((sum, p) => sum + p.total, 0);
    const unreadNotifications = notifications.filter(n => !n.read).length;

    setStats({
      totalPurchases: userPurchases.length,
      totalSpent,
      unreadNotifications
    });
  }, [user.id, notifications]);

  const markNotificationAsRead = (notificationId) => {
    const updatedNotifications = notifications.map(n => 
      n.id === notificationId ? {...n, read: true} : n
    );
    setNotifications(updatedNotifications);
    localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
  };

  const downloadApp = (purchase, item) => {
    // Simulate download
    const link = document.createElement('a');
    link.href = item.downloadUrl || '#';
    link.download = `${item.name}.apk`;
    link.click();
    
    // In real implementation, this would trigger actual download
    alert(`🚧 Fitur download belum diimplementasikan - tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀`);
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">
            <User className="inline h-10 w-10 mr-3 text-purple-400" />
            Dashboard User
          </h1>
          <p className="text-xl text-gray-400">Selamat datang kembali, {user.username}!</p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-lg border-purple-500/20">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Total Pembelian</CardTitle>
                <ShoppingBag className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats.totalPurchases}</div>
                <p className="text-xs text-gray-400">Aplikasi yang dibeli</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 backdrop-blur-lg border-green-500/20">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Total Pengeluaran</CardTitle>
                <i className="fas fa-money-bill-wave text-green-400"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Rp {stats.totalSpent.toLocaleString()}</div>
                <p className="text-xs text-gray-400">Sepanjang waktu</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-yellow-900/50 to-orange-900/50 backdrop-blur-lg border-yellow-500/20">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Notifikasi</CardTitle>
                <Bell className="h-4 w-4 text-yellow-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats.unreadNotifications}</div>
                <p className="text-xs text-gray-400">Belum dibaca</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Tabs defaultValue="purchases" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800/50 border border-slate-700">
              <TabsTrigger value="purchases" className="data-[state=active]:bg-purple-600">
                <ShoppingBag className="h-4 w-4 mr-2" />
                Pembelian Saya
              </TabsTrigger>
              <TabsTrigger value="downloads" className="data-[state=active]:bg-purple-600">
                <Download className="h-4 w-4 mr-2" />
                Download
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-purple-600">
                <Bell className="h-4 w-4 mr-2" />
                Notifikasi
              </TabsTrigger>
            </TabsList>

            <TabsContent value="purchases" className="space-y-4">
              {purchases.length === 0 ? (
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="flex flex-col items-center justify-center py-16">
                    <ShoppingBag className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Belum Ada Pembelian</h3>
                    <p className="text-gray-400 text-center">Mulai jelajahi store untuk menemukan aplikasi premium terbaik</p>
                  </CardContent>
                </Card>
              ) : (
                purchases.map((purchase, index) => (
                  <motion.div
                    key={purchase.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-lg border-purple-500/20">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-white">
                              Pesanan #{purchase.id.toString().slice(-6)}
                            </CardTitle>
                            <CardDescription className="flex items-center space-x-2 mt-1">
                              <Calendar className="h-4 w-4" />
                              <span>{new Date(purchase.timestamp).toLocaleDateString('id-ID')}</span>
                              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">
                                {purchase.status === 'completed' ? 'Selesai' : 'Pending'}
                              </span>
                            </CardDescription>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-purple-400">
                              Rp {purchase.total.toLocaleString()}
                            </p>
                            {purchase.discount > 0 && (
                              <p className="text-sm text-green-400">
                                Hemat Rp {purchase.discount.toLocaleString()}
                              </p>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {purchase.items.map((item, itemIndex) => (
                            <div key={itemIndex} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                              <div className="flex items-center space-x-3">
                                <img 
                                  src={item.image} 
                                  alt={item.name}
                                  className="w-12 h-12 object-cover rounded-lg"
                                />
                                <div>
                                  <h4 className="font-semibold text-white">{item.name}</h4>
                                  <p className="text-sm text-gray-400">{item.category}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold text-purple-400">
                                  Rp {item.price.toLocaleString()}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </TabsContent>

            <TabsContent value="downloads" className="space-y-4">
              {purchases.length === 0 ? (
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="flex flex-col items-center justify-center py-16">
                    <Download className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Tidak Ada Download</h3>
                    <p className="text-gray-400 text-center">Beli aplikasi terlebih dahulu untuk mulai download</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {purchases.flatMap(purchase => 
                    purchase.items.map((item, index) => (
                      <motion.div
                        key={`${purchase.id}-${index}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Card className="bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-lg border-purple-500/20 hover:border-purple-500/40 transition-all">
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-4 mb-4">
                              <img 
                                src={item.image} 
                                alt={item.name}
                                className="w-16 h-16 object-cover rounded-lg"
                              />
                              <div className="flex-1">
                                <h3 className="font-bold text-white">{item.name}</h3>
                                <p className="text-sm text-gray-400">{item.category}</p>
                                <div className="flex items-center space-x-1 mt-1">
                                  <Star className="h-4 w-4 text-yellow-400" />
                                  <span className="text-sm text-gray-300">4.9</span>
                                </div>
                              </div>
                            </div>
                            
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => downloadApp(purchase, item)}
                              className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg text-white font-semibold hover:shadow-lg hover:shadow-green-500/25 transition-all flex items-center justify-center space-x-2"
                            >
                              <Download className="h-5 w-5" />
                              <span>Download APK</span>
                            </motion.button>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="notifications" className="space-y-4">
              {notifications.length === 0 ? (
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="flex flex-col items-center justify-center py-16">
                    <Bell className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Tidak Ada Notifikasi</h3>
                    <p className="text-gray-400 text-center">Notifikasi akan muncul di sini</p>
                  </CardContent>
                </Card>
              ) : (
                notifications.map((notification, index) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => markNotificationAsRead(notification.id)}
                    className="cursor-pointer"
                  >
                    <Card className={`transition-all hover:scale-[1.02] ${
                      notification.read 
                        ? 'bg-slate-800/30 border-slate-700' 
                        : 'bg-gradient-to-br from-blue-900/50 to-purple-900/50 border-blue-500/20'
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className={`p-2 rounded-full ${
                            notification.read ? 'bg-gray-600' : 'bg-blue-600'
                          }`}>
                            <Bell className="h-4 w-4 text-white" />
                          </div>
                          <div className="flex-1">
                            <p className={`${notification.read ? 'text-gray-400' : 'text-white'}`}>
                              {notification.message}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(notification.timestamp).toLocaleString('id-ID')}
                            </p>
                          </div>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default UserDashboard;