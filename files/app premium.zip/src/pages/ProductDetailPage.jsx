import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Star, Download, ShoppingCart, Shield, Zap, Users, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ProductDetailPage = ({ product, user, setCurrentPage, addToCart }) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const { toast } = useToast();

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Produk tidak ditemukan</h2>
          <button
            onClick={() => setCurrentPage('store')}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            Kembali ke Store
          </button>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Login Diperlukan! 🔐",
        description: "Silakan login terlebih dahulu untuk berbelanja",
        variant: "destructive"
      });
      setCurrentPage('login');
      return;
    }
    addToCart(product);
  };

  const handleBuyNow = () => {
    if (!user) {
      toast({
        title: "Login Diperlukan! 🔐",
        description: "Silakan login terlebih dahulu untuk berbelanja",
        variant: "destructive"
      });
      setCurrentPage('login');
      return;
    }
    addToCart(product);
    setCurrentPage('checkout');
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setCurrentPage('store')}
          className="flex items-center space-x-2 mb-8 px-4 py-2 bg-slate-800/50 rounded-lg text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Kembali ke Store</span>
        </motion.button>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <div className="relative mb-4">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-96 object-cover rounded-xl"
                />
                <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full font-semibold flex items-center">
                  <Star className="h-4 w-4 mr-1" />
                  4.9
                </div>
                {product.originalPrice && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full font-semibold">
                    SALE {Math.round((1 - product.price / product.originalPrice) * 100)}%
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-4 gap-2">
                {[product.image, product.image, product.image, product.image].map((img, index) => (
                  <motion.img
                    key={index}
                    whileHover={{ scale: 1.05 }}
                    src={img}
                    alt={`${product.name} ${index + 1}`}
                    className={`h-20 object-cover rounded-lg cursor-pointer border-2 transition-all ${
                      selectedImage === index ? 'border-purple-500' : 'border-transparent'
                    }`}
                    onClick={() => setSelectedImage(index)}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-6"
          >
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-sm text-purple-400 bg-purple-400/20 px-3 py-1 rounded-full">
                  {product.category}
                </span>
                <div className="flex items-center text-green-400 text-sm">
                  <Download className="h-4 w-4 mr-1" />
                  <span>{product.stock} tersedia</span>
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-white mb-4">{product.name}</h1>
              <p className="text-gray-300 text-lg leading-relaxed">{product.description}</p>
            </div>

            {/* Price */}
            <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl p-6 border border-purple-500/20">
              <div className="flex items-center space-x-4">
                <div>
                  <span className="text-3xl font-bold text-purple-400">
                    Rp {product.price.toLocaleString()}
                  </span>
                  {product.originalPrice && (
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-lg text-gray-500 line-through">
                        Rp {product.originalPrice.toLocaleString()}
                      </span>
                      <span className="text-green-400 font-semibold">
                        Hemat Rp {(product.originalPrice - product.price).toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Features */}
            {product.features && (
              <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
                <h3 className="text-xl font-bold text-white mb-4">
                  <i className="fas fa-star mr-2 text-yellow-400"></i>
                  Fitur Utama
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {product.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Check className="h-5 w-5 text-green-400" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                <Shield className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <p className="text-sm text-gray-300">Aman & Terpercaya</p>
              </div>
              <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                <Zap className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                <p className="text-sm text-gray-300">Download Instan</p>
              </div>
              <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                <Users className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <p className="text-sm text-gray-300">Support 24/7</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleAddToCart}
                className="flex-1 py-4 bg-transparent border-2 border-purple-500 rounded-xl text-purple-400 font-semibold hover:bg-purple-500/10 transition-all flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>Tambah ke Keranjang</span>
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleBuyNow}
                className="flex-1 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all flex items-center justify-center space-x-2"
              >
                <i className="fas fa-bolt"></i>
                <span>Beli Sekarang</span>
              </motion.button>
            </div>

            {/* Additional Info */}
            <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/20">
              <div className="flex items-center space-x-2 text-blue-300">
                <i className="fas fa-info-circle"></i>
                <span className="font-semibold">Informasi Penting:</span>
              </div>
              <p className="text-blue-200 mt-2 text-sm">
                Setelah pembayaran berhasil, link download akan dikirim otomatis ke email Anda dan tersedia di dashboard.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;