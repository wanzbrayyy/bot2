import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { config } from '@/config';

const LoginPage = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(formData.email, formData.password);
      navigate(user.role === 'admin' ? '/admin' : '/dashboard');
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center p-4 relative">
      <Helmet>
        <title>Login - {config.appName}</title>
        <meta name="description" content={`Masuk ke akun ${config.appName} Anda.`} />
      </Helmet>

      <Button onClick={() => navigate(-1)} className="back-button" variant="ghost">
        <ArrowLeft className="mr-2" /> Kembali
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="glass-effect border-white/20 bg-white/10">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-user text-white text-2xl"></i>
            </div>
            <CardTitle className="text-3xl font-bold text-white">Masuk Akun</CardTitle>
            <p className="text-white/70">Selamat datang kembali! 👋</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-envelope mr-2"></i>Email</label>
                <Input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Masukkan email Anda" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-lock mr-2"></i>Password</label>
                <Input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Masukkan password Anda" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-3">
                {loading ? <><i className="fas fa-spinner fa-spin mr-2"></i>Memproses...</> : <><i className="fas fa-sign-in-alt mr-2"></i>Masuk</>}
              </Button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-white/70">
                Belum punya akun?{' '}
                <Link to="/register" className="text-purple-300 hover:text-purple-200 font-medium">Daftar di sini</Link>
              </p>
            </div>
            <div className="mt-4 p-4 bg-blue-500/20 rounded-lg border border-blue-400/30">
              <p className="text-blue-200 text-sm text-center mb-2"><i className="fas fa-info-circle mr-2"></i>Demo Account</p>
              <p className="text-blue-100 text-xs text-center">Admin: wanzofc@admin.com / wanzofc</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default LoginPage;