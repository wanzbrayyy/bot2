import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, XCircle } from 'lucide-react';
import { config } from '@/config';

const PaymentResultPage = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const status = queryParams.get('status');
  const orderId = queryParams.get('order_id');

  const isSuccess = status === 'success';

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center p-4">
      <Helmet>
        <title>Hasil Pembayaran - {config.appName}</title>
      </Helmet>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: 'spring' }}
        className="w-full max-w-md"
      >
        <Card className="glass-effect border-white/20 bg-white/10 text-white">
          <CardHeader className="text-center">
            {isSuccess ? (
              <CheckCircle className="mx-auto h-16 w-16 text-green-400" />
            ) : (
              <XCircle className="mx-auto h-16 w-16 text-red-400" />
            )}
            <CardTitle className="text-3xl font-bold mt-4">
              {isSuccess ? 'Pembayaran Berhasil!' : 'Pembayaran Gagal'}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-white/80">
              {isSuccess
                ? 'Terima kasih! Pesanan Anda sedang diproses. Anda dapat melihat detail pesanan dan mengunduh produk di dashboard Anda.'
                : 'Maaf, terjadi masalah dengan pembayaran Anda. Silakan coba lagi atau hubungi dukungan pelanggan.'}
            </p>
            {orderId && (
              <p className="text-sm text-white/60">
                ID Pesanan: {orderId}
              </p>
            )}
            <div className="flex justify-center gap-4 pt-4">
              <Link to="/dashboard">
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                  <i className="fas fa-tachometer-alt mr-2"></i>
                  Ke Dashboard
                </Button>
              </Link>
              <Link to="/store">
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <i className="fas fa-store mr-2"></i>
                  Lanjut Belanja
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default PaymentResultPage;