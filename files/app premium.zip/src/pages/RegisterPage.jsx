import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { config } from '@/config';

const RegisterPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Password tidak cocok!');
      return;
    }
    setLoading(true);
    try {
      await register({ name: formData.name, email: formData.email, password: formData.password });
      navigate('/dashboard');
    } catch (error) {
      console.error('Register error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center p-4 relative">
      <Helmet>
        <title>Daftar - {config.appName}</title>
        <meta name="description" content={`Buat akun di ${config.appName}.`} />
      </Helmet>

      <Button onClick={() => navigate(-1)} className="back-button" variant="ghost">
        <ArrowLeft className="mr-2" /> Kembali
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="glass-effect border-white/20 bg-white/10">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-user-plus text-white text-2xl"></i>
            </div>
            <CardTitle className="text-3xl font-bold text-white">Buat Akun</CardTitle>
            <p className="text-white/70">Bergabunglah dengan kami! 🚀</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-user mr-2"></i>Nama Lengkap</label>
                <Input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Masukkan nama lengkap" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-envelope mr-2"></i>Email</label>
                <Input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Masukkan email Anda" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-lock mr-2"></i>Password</label>
                <Input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Buat password yang kuat" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-lock mr-2"></i>Konfirmasi Password</label>
                <Input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} placeholder="Ulangi password Anda" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-3">
                {loading ? <><i className="fas fa-spinner fa-spin mr-2"></i>Memproses...</> : <><i className="fas fa-user-plus mr-2"></i>Daftar Sekarang</>}
              </Button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-white/70">
                Sudah punya akun?{' '}
                <Link to="/login" className="text-purple-300 hover:text-purple-200 font-medium">Masuk di sini</Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default RegisterPage;