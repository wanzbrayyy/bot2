import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { config } from '@/config';
import LoadingScreen from '@/components/LoadingScreen';

const HomePage = () => {
  const { products, promoTimers } = useStore();
  const [loading, setLoading] = useState(true);
  const featuredProducts = products ? products.slice(0, 3) : [];

  const handleLoadingFinish = () => {
    setLoading(false);
    if (Notification.permission !== "granted" && Notification.permission !== "denied") {
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          new Notification("Terima kasih!", {
            body: "Anda akan menerima notifikasi untuk produk & promo terbaru!",
            icon: "/vite.svg"
          });
        }
      });
    }
  };

  if (loading) {
    return <LoadingScreen onFinished={handleLoadingFinish} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
      <Helmet>
        <title>{config.appName} - Your Digital Marketplace</title>
        <meta name="description" content="Temukan source code, aplikasi premium, dan bot terbaik di wanzofc shop. Jadilah seller dan raih keuntungan." />
      </Helmet>
      
      <Navbar />

      {promoTimers && promoTimers.length > 0 && promoTimers[0].active && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 md:mt-20 mx-4 mb-4"
        >
          <div className="glass-effect rounded-lg p-4 border border-yellow-400/30 bg-yellow-400/10">
            <div className="flex items-center justify-center space-x-3">
              <i className="fas fa-stopwatch text-yellow-400 text-xl"></i>
              <p className="text-white font-medium">{promoTimers[0].title}</p>
              {/* Timer component would go here */}
            </div>
          </div>
        </motion.div>
      )}

      <section className="pt-24 md:pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-black text-white mb-6 leading-tight">
              {config.appName}
              <span className="block gradient-text">Digital Marketplace</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto">
              Temukan source code, aplikasi premium, dan bot terbaik. Atau jadi seller dan raih keuntungan! 🚀
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/store">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-4 text-lg pulse-glow"
                >
                  <i className="fas fa-shopping-cart mr-3"></i>
                  Mulai Belanja
                </Button>
              </Link>
              
              <Link to="/seller-registration">
                <Button 
                  size="lg" 
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg"
                >
                  <i className="fas fa-handshake mr-3"></i>
                  Jadi Seller
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Produk Unggulan 🔥
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="glass-effect rounded-2xl overflow-hidden card-hover"
              >
                <div className="h-48 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <i className="fas fa-mobile-alt text-white text-6xl"></i>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{product.name}</h3>
                  <p className="text-white/70 mb-4 text-sm">{product.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-white">
                      Rp {product.price.toLocaleString()}
                    </span>
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-yellow-400"></i>
                      <span className="text-white text-sm">{product.rating}</span>
                    </div>
                  </div>

                  <Link to={`/product/${product.slug}`}>
                    <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                      <i className="fas fa-eye mr-2"></i>
                      Lihat Detail
                    </Button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-12 px-4 border-t border-white/10 mt-20">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <i className="fas fa-store text-white text-xl"></i>
            </div>
            <span className="text-2xl font-bold text-white">{config.appName}</span>
          </div>
          
          <p className="text-white/60 mb-6">
            Platform terpercaya untuk produk digital berkualitas.
          </p>
          
          <div className="flex justify-center space-x-6 mb-6">
            <a href={`https://wa.me/${config.contact.whatsapp}`} target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
              <i className="fab fa-whatsapp text-2xl"></i>
            </a>
            <a href={`https://instagram.com/${config.contact.instagram}`} target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
              <i className="fab fa-instagram text-2xl"></i>
            </a>
            <a href={`https://twitter.com/${config.contact.twitter}`} target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
              <i className="fab fa-twitter text-2xl"></i>
            </a>
          </div>
          
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} {config.appName}. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;