import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { config } from '@/config';
import { toast } from '@/components/ui/use-toast';

const SellerRegistrationPage = () => {
  const [formData, setFormData] = useState({ shopName: '', idCard: null });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    toast({
      title: "🚧 Fitur Pendaftaran Seller belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: "Data Anda akan diproses setelah backend siap.",
    });
    setTimeout(() => {
      setLoading(false);
      navigate('/dashboard');
    }, 2000);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center p-4 relative">
      <Helmet>
        <title>Pendaftaran Seller - {config.appName}</title>
        <meta name="description" content={`Jadilah seller di ${config.appName} dan mulai berjualan.`} />
      </Helmet>

      <Button onClick={() => navigate(-1)} className="back-button" variant="ghost">
        <ArrowLeft className="mr-2" /> Kembali
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-lg"
      >
        <Card className="glass-effect border-white/20 bg-white/10">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-handshake text-white text-2xl"></i>
            </div>
            <CardTitle className="text-3xl font-bold text-white">Pendaftaran Seller</CardTitle>
            <p className="text-white/70">Mulai berjualan di platform kami!</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-store mr-2"></i>Nama Toko</label>
                <Input type="text" name="shopName" value={formData.shopName} onChange={handleChange} placeholder="Masukkan nama toko Anda" className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
              </div>
              <div>
                <label className="block text-white font-medium mb-2"><i className="fas fa-id-card mr-2"></i>Upload KTP</label>
                <Input type="file" name="idCard" onChange={(e) => setFormData({...formData, idCard: e.target.files[0]})} className="bg-white/10 border-white/20 text-white file:text-white/70 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-500/20 hover:file:bg-purple-500/40" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-3">
                {loading ? <><i className="fas fa-spinner fa-spin mr-2"></i>Mengirim...</> : <><i className="fas fa-paper-plane mr-2"></i>Kirim Pendaftaran</>}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default SellerRegistrationPage;