import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, CreditCard, Trash2, Tag } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const CheckoutPage = ({ cart, setCart, user, setCurrentPage, promoCodes }) => {
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
  const discount = appliedPromo ? 
    (appliedPromo.discountType === 'percentage' ? 
      subtotal * (appliedPromo.discount / 100) : 
      appliedPromo.discount) : 0;
  const total = subtotal - discount;

  const removeFromCart = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    toast({
      title: "Item Dihapus",
      description: "Produk berhasil dihapus dari keranjang",
    });
  };

  const applyPromoCode = () => {
    const promo = promoCodes.find(p => p.code === promoCode && p.isActive);
    if (promo) {
      if (promo.usedCount >= promo.usageLimit) {
        toast({
          title: "Kode Promo Tidak Valid",
          description: "Kode promo sudah mencapai batas penggunaan",
          variant: "destructive"
        });
        return;
      }
      setAppliedPromo(promo);
      toast({
        title: "Kode Promo Berhasil! 🎉",
        description: `Diskon ${promo.discountType === 'percentage' ? promo.discount + '%' : 'Rp ' + promo.discount.toLocaleString()} diterapkan`,
      });
    } else {
      toast({
        title: "Kode Promo Tidak Valid",
        description: "Kode promo tidak ditemukan atau sudah tidak aktif",
        variant: "destructive"
      });
    }
  };

  const processPayment = () => {
    if (!user) {
      toast({
        title: "Login Diperlukan",
        description: "Silakan login terlebih dahulu",
        variant: "destructive"
      });
      setCurrentPage('login');
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      // Save purchase to localStorage
      const purchases = JSON.parse(localStorage.getItem('purchases') || '[]');
      const newPurchase = {
        id: Date.now(),
        userId: user.id,
        items: cart,
        subtotal,
        discount,
        total,
        promoCode: appliedPromo?.code,
        timestamp: new Date().toISOString(),
        status: 'completed'
      };
      
      purchases.push(newPurchase);
      localStorage.setItem('purchases', JSON.stringify(purchases));

      // Update promo code usage
      if (appliedPromo) {
        const updatedPromoCodes = promoCodes.map(p => 
          p.code === appliedPromo.code ? {...p, usedCount: p.usedCount + 1} : p
        );
        localStorage.setItem('promoCodes', JSON.stringify(updatedPromoCodes));
      }

      setCart([]);
      setIsProcessing(false);
      
      toast({
        title: "Pembayaran Berhasil! 🎉",
        description: "Aplikasi Anda sudah bisa didownload di dashboard",
      });
      
      setCurrentPage('user-dashboard');
    }, 3000);
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="text-6xl mb-4">🛒</div>
          <h2 className="text-3xl font-bold text-white mb-4">Keranjang Kosong</h2>
          <p className="text-gray-400 mb-8">Belum ada produk di keranjang Anda</p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentPage('store')}
            className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all"
          >
            Mulai Belanja
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center space-x-4 mb-8"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentPage('store')}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-800/50 rounded-lg text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Kembali</span>
          </motion.button>
          <h1 className="text-3xl font-bold text-white">
            <i className="fas fa-shopping-cart mr-3 text-purple-400"></i>
            Checkout
          </h1>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Item Pesanan</h2>
              
              <div className="space-y-4">
                {cart.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center space-x-4 p-4 bg-slate-700/30 rounded-xl border border-slate-600/30"
                  >
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{item.name}</h3>
                      <p className="text-sm text-gray-400">{item.category}</p>
                      <p className="text-lg font-bold text-purple-400">
                        Rp {item.price.toLocaleString()}
                      </p>
                    </div>
                    
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => removeFromCart(index)}
                      className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-5 w-5" />
                    </motion.button>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20 sticky top-8"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Ringkasan Pesanan</h2>
              
              {/* Promo Code */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  <Tag className="inline h-4 w-4 mr-1" />
                  Kode Promo
                </label>
                <div className="flex space-x-2">
                  <Input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Masukkan kode promo"
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-gray-400 focus:border-purple-500"
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={applyPromoCode}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    Terapkan
                  </motion.button>
                </div>
                {appliedPromo && (
                  <div className="mt-2 p-2 bg-green-900/20 border border-green-500/20 rounded-lg">
                    <p className="text-green-400 text-sm">
                      ✅ Kode "{appliedPromo.code}" berhasil diterapkan
                    </p>
                  </div>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-gray-300">
                  <span>Subtotal ({cart.length} item)</span>
                  <span>Rp {subtotal.toLocaleString()}</span>
                </div>
                
                {discount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span>Diskon</span>
                    <span>-Rp {discount.toLocaleString()}</span>
                  </div>
                )}
                
                <div className="border-t border-slate-600 pt-3">
                  <div className="flex justify-between text-xl font-bold text-white">
                    <span>Total</span>
                    <span>Rp {total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Payment Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={processPayment}
                disabled={isProcessing}
                className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <i className="fas fa-spinner fa-spin"></i>
                    <span>Memproses Pembayaran...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="h-5 w-5" />
                    <span>Bayar Sekarang</span>
                  </>
                )}
              </motion.button>

              {/* Payment Info */}
              <div className="mt-4 p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
                <div className="flex items-center space-x-2 text-blue-300 mb-2">
                  <i className="fas fa-shield-alt"></i>
                  <span className="font-semibold">Pembayaran Aman</span>
                </div>
                <p className="text-blue-200 text-sm">
                  🚧 Integrasi Xendit belum diimplementasikan - tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;