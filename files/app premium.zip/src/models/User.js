export const UserSchema = {
  id: String,
  name: String,
  email: String,
  password: String, // Hashed in a real app
  role: String, // 'user', 'seller', 'admin'
  createdAt: String,
  
  // For sellers
  shopName: String,
  isSellerVerified: Boolean,
  paymentSettings: {
    midtrans: {
      clientKey: String,
      isProduction: Boolean,
    },
    xendit: {
      publicKey: String,
    }
  },

  purchases: [
    {
      orderId: String,
      productId: String,
      productName: String,
      purchaseDate: String,
      result: [String] // Array of credentials or download links
    }
  ],
  
  notifications: [
    {
      id: String,
      message: String,
      createdAt: String,
      read: Boolean
    }
  ]
};