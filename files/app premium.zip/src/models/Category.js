export const CategorySchema = {
  id: String,
  name: String,
  slug: String,
  icon: String, // Font Awesome class
  createdAt: String,
};