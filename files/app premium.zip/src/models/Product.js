export const ProductSchema = {
  id: String,
  name: String,
  slug: String,
  description: String,
  price: Number,
  originalPrice: Number,
  category: String, // 'Aplikasi Premium', 'Source Code', 'Bot'
  type: String, // 'credentials' or 'file'
  stock: Number,
  
  // For type 'credentials'
  credentials: [{
    id: String,
    data: String, // e.g., "email:pass"
    isSold: Boolean,
  }],

  // For type 'file'
  downloadUrl: String,
  fileInfo: {
    name: String,
    size: Number,
    type: String, // e.g., 'application/zip'
  },

  previewImages: [String],
  features: [String],
  rating: Number,
  reviews: Number,
  sellerId: String, // 'admin' or user ID
  createdAt: String,
};