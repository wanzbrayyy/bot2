export const PromoTimerSchema = {
  id: String,
  title: String,
  endDate: String,
  active: Boolean,
  type: String, // 'promo-product', 'partner-seller'
  createdAt: String,
};