export const config = {
  appName: 'wanzofc shop',
  currency: 'IDR',
  locale: 'id-ID',

  xendit: {
    publicKey: 'YOUR_XENDIT_PUBLIC_KEY_HERE',
    environment: 'test' // 'live' for production
  },

  midtrans: {
    clientKey: 'YOUR_MIDTRANS_CLIENT_KEY_HERE',
    serverKey: 'YOUR_MIDTRANS_SERVER_KEY_HERE', // server-side only
    isProduction: false
  },

  mongodb: {
    uri: 'YOUR_MONGODB_CONNECTION_STRING_HERE'
  },
  
  contact: {
    whatsapp: '088801074059',
    instagram: 'wanz_brayy',
    twitter: 'Maverick'
  }
};