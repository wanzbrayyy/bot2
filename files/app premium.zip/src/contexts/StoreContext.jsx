import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';
import { createSlug } from '@/lib/utils';

const StoreContext = createContext();

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};

export const StoreProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [promoCodes, setPromoCodes] = useState([]);
  const [broadcasts, setBroadcasts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [promoTimers, setPromoTimers] = useState([]);

  useEffect(() => {
    const defaultProducts = [
      {
        id: '1',
        name: 'Premium Photo Editor Pro',
        slug: createSlug('Premium Photo Editor Pro'),
        description: 'Editor foto profesional dengan fitur AI terdepan',
        price: 99000,
        originalPrice: 199000,
        category: 'Photography',
        stock: 50,
        downloadUrl: '/files/photo-editor-pro.apk',
        features: ['AI Enhancement', 'RAW Support', 'Cloud Sync', 'Premium Filters'],
        rating: 4.8,
        reviews: 1250,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Music Studio Ultimate',
        slug: createSlug('Music Studio Ultimate'),
        description: 'Studio musik lengkap di genggaman Anda',
        price: 149000,
        originalPrice: 299000,
        category: 'Music',
        stock: 30,
        downloadUrl: '/files/music-studio.apk',
        features: ['Multi-track Recording', 'VST Support', 'MIDI Controller', 'Export HD'],
        rating: 4.9,
        reviews: 890,
        createdAt: new Date().toISOString()
      },
      {
        id: '3',
        name: 'Video Editor Pro Max',
        slug: createSlug('Video Editor Pro Max'),
        description: 'Edit video seperti profesional dengan mudah',
        price: 179000,
        originalPrice: 359000,
        category: 'Video',
        stock: 25,
        downloadUrl: '/files/video-editor-pro.apk',
        features: ['4K Export', 'Motion Graphics', 'Color Grading', 'Audio Mixing'],
        rating: 4.7,
        reviews: 2100,
        createdAt: new Date().toISOString()
      }
    ];

    const defaultPromoCodes = [
      {
        id: '1',
        code: 'WELCOME50',
        discount: 50000,
        type: 'fixed',
        description: 'Diskon Rp 50.000 untuk pembelian pertama',
        minPurchase: 100000,
        maxUse: 100,
        used: 25,
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        active: true
      },
      {
        id: '2',
        code: 'PREMIUM25',
        discount: 25,
        type: 'percentage',
        description: 'Diskon 25% untuk semua produk premium',
        minPurchase: 50000,
        maxUse: 50,
        used: 12,
        validUntil: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
        active: true
      }
    ];

    const defaultPromoTimers = [
      {
        id: '1',
        title: 'FLASH SALE! Diskon hingga 50% untuk semua produk!',
        endDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        active: true,
        type: 'promo-product',
        createdAt: new Date().toISOString()
      }
    ];

    const savedProducts = localStorage.getItem('products');
    const savedPromoCodes = localStorage.getItem('promoCodes');
    const savedBroadcasts = localStorage.getItem('broadcasts');
    const savedOrders = localStorage.getItem('orders');
    const savedPromoTimers = localStorage.getItem('promoTimers');

    if (!savedProducts) {
      localStorage.setItem('products', JSON.stringify(defaultProducts));
      setProducts(defaultProducts);
    } else {
      setProducts(JSON.parse(savedProducts));
    }

    if (!savedPromoCodes) {
      localStorage.setItem('promoCodes', JSON.stringify(defaultPromoCodes));
      setPromoCodes(defaultPromoCodes);
    } else {
      setPromoCodes(JSON.parse(savedPromoCodes));
    }

    if (!savedPromoTimers) {
      localStorage.setItem('promoTimers', JSON.stringify(defaultPromoTimers));
      setPromoTimers(defaultPromoTimers);
    } else {
      setPromoTimers(JSON.parse(savedPromoTimers));
    }

    if (savedBroadcasts) {
      setBroadcasts(JSON.parse(savedBroadcasts));
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const adminExists = users.find(u => u.email === 'wanzofc@admin.com');
    
    if (!adminExists) {
      const adminUser = {
        id: 'admin-1',
        name: 'Admin',
        email: 'wanzofc@admin.com',
        password: 'wanzofc',
        role: 'admin',
        createdAt: new Date().toISOString(),
        purchases: [],
        notifications: []
      };
      users.push(adminUser);
      localStorage.setItem('users', JSON.stringify(users));
    }
  }, []);

  const addProduct = (productData) => {
    const newProduct = {
      id: Date.now().toString(),
      ...productData,
      slug: createSlug(productData.name),
      createdAt: new Date().toISOString(),
      rating: 0,
      reviews: 0
    };

    const updatedProducts = [...products, newProduct];
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));

    notifyAllUsers('Admin menambahkan produk baru: ' + newProduct.name);

    toast({
      title: "Produk Ditambahkan! 🎉",
      description: `${newProduct.name} berhasil ditambahkan ke store`,
    });
  };

  const updateProduct = (id, productData) => {
    const updatedProducts = products.map(p => 
      p.id === id ? { ...p, ...productData, slug: createSlug(productData.name) } : p
    );
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));

    toast({
      title: "Produk Diperbarui! ✨",
      description: "Perubahan berhasil disimpan",
    });
  };

  const deleteProduct = (id) => {
    const updatedProducts = products.filter(p => p.id !== id);
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));

    toast({
      title: "Produk Dihapus",
      description: "Produk berhasil dihapus dari store",
    });
  };

  const addPromoCode = (promoData) => {
    const newPromo = {
      id: Date.now().toString(),
      ...promoData,
      used: 0,
      createdAt: new Date().toISOString()
    };

    const updatedPromoCodes = [...promoCodes, newPromo];
    setPromoCodes(updatedPromoCodes);
    localStorage.setItem('promoCodes', JSON.stringify(updatedPromoCodes));

    notifyAllUsers('Kode promo baru tersedia: ' + newPromo.code);

    toast({
      title: "Kode Promo Ditambahkan! 🎁",
      description: `Kode ${newPromo.code} berhasil dibuat`,
    });
  };

  const validatePromoCode = (code, totalAmount) => {
    const promo = promoCodes.find(p => 
      p.code === code && 
      p.active && 
      p.used < p.maxUse &&
      new Date(p.validUntil) > new Date() &&
      totalAmount >= p.minPurchase
    );

    if (!promo) {
      return { valid: false, message: 'Kode promo tidak valid atau sudah expired' };
    }

    const discount = promo.type === 'percentage' 
      ? Math.floor(totalAmount * promo.discount / 100)
      : promo.discount;

    return { 
      valid: true, 
      discount,
      promo,
      message: `Diskon ${promo.type === 'percentage' ? promo.discount + '%' : 'Rp ' + promo.discount.toLocaleString()}`
    };
  };

  const addBroadcast = (message) => {
    const newBroadcast = {
      id: Date.now().toString(),
      message,
      createdAt: new Date().toISOString()
    };

    const updatedBroadcasts = [newBroadcast, ...broadcasts];
    setBroadcasts(updatedBroadcasts);
    localStorage.setItem('broadcasts', JSON.stringify(updatedBroadcasts));

    notifyAllUsers('Pengumuman: ' + message);

    toast({
      title: "Broadcast Terkirim! 📢",
      description: "Pesan berhasil dikirim ke semua user",
    });
  };

  const notifyAllUsers = (message) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map(user => {
      if (user.role !== 'admin') {
        return {
          ...user,
          notifications: [
            {
              id: Date.now().toString() + Math.random(),
              message,
              createdAt: new Date().toISOString(),
              read: false
            },
            ...(user.notifications || [])
          ]
        };
      }
      return user;
    });
    localStorage.setItem('users', JSON.stringify(updatedUsers));
  };

  const createOrder = (orderData) => {
    const newOrder = {
      id: Date.now().toString(),
      ...orderData,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    const updatedOrders = [...orders, newOrder];
    setOrders(updatedOrders);
    localStorage.setItem('orders', JSON.stringify(updatedOrders));

    return newOrder;
  };

  const value = {
    products,
    promoCodes,
    broadcasts,
    orders,
    promoTimers,
    addProduct,
    updateProduct,
    deleteProduct,
    addPromoCode,
    validatePromoCode,
    addBroadcast,
    createOrder
  };

  return (
    <StoreContext.Provider value={value}>
      {children}
    </StoreContext.Provider>
  );
};