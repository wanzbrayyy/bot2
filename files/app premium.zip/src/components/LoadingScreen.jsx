import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text } from '@react-three/drei';
import { motion } from 'framer-motion';
import { config } from '@/config';

function Word({ children, ...props }) {
  return (
    <Text
      {...props}
      font="/fonts/Poppins-Bold.ttf"
      fontSize={2}
      letterSpacing={-0.05}
      color="white"
    >
      {children}
    </Text>
  );
}

const LoadingScreen = ({ onFinished }) => {
  return (
    <motion.div
      className="fixed inset-0 bg-black z-[100] flex items-center justify-center"
      initial={{ opacity: 1 }}
      animate={{ opacity: 0, transitionEnd: { display: 'none' } }}
      transition={{ delay: 3, duration: 1 }}
      onAnimationComplete={onFinished}
    >
      <Canvas dpr={[1, 2]} camera={{ position: [0, 0, 15], fov: 45 }}>
        <fog attach="fog" args={['#202025', 0, 80]} />
        <Suspense fallback={null}>
          <group>
            <Word position={[0, 0, 0]}>{config.appName}</Word>
          </group>
        </Suspense>
        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={1.5} />
      </Canvas>
    </motion.div>
  );
};

export default LoadingScreen;