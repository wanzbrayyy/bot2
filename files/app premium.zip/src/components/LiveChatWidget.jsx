import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

const LiveChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  const handleChatSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Fitur Live Chat belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: "Pesan Anda akan terkirim setelah integrasi backend.",
    });
    setIsOpen(false);
  };

  if (!user) return null;

  return (
    <>
      <div className="fixed bottom-20 right-4 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="rounded-full w-14 h-14 bg-gradient-to-r from-purple-500 to-pink-500 pulse-glow"
        >
          {isOpen ? <X /> : <MessageSquare />}
        </Button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-36 right-4 z-50 w-80 glass-effect rounded-lg shadow-2xl border border-white/20"
          >
            <div className="p-4 bg-black/20 rounded-t-lg">
              <h3 className="font-bold text-white">Live Chat</h3>
              <p className="text-xs text-white/70">Butuh bantuan? Kami siap membantu!</p>
            </div>
            <div className="p-4 h-64 overflow-y-auto">
              {/* Chat messages will go here */}
              <div className="text-center text-sm text-white/50">
                Mulai percakapan...
              </div>
            </div>
            <form onSubmit={handleChatSubmit} className="p-4 border-t border-white/10 flex gap-2">
              <Input
                placeholder="Ketik pesan..."
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              />
              <Button type="submit" size="icon" className="bg-purple-500 hover:bg-purple-600">
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default LiveChatWidget;