import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useStore } from '@/contexts/StoreContext';

const OrdersTab = () => {
  const { orders } = useStore();

  return (
    <Card className="glass-effect border-white/20 bg-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <i className="fas fa-shopping-cart mr-3"></i>Daftar Pesanan
        </CardTitle>
      </CardHeader>
      <CardContent>
        {orders.length === 0 ? (
          <div className="text-center py-12">
            <i className="fas fa-shopping-cart text-white/30 text-6xl mb-6"></i>
            <h3 className="text-xl font-bold text-white mb-4">Belum Ada Pesanan</h3>
            <p className="text-white/70">Pesanan akan muncul di sini setelah ada transaksi</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="glass-effect rounded-lg p-4 border border-white/10">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="text-white font-semibold">{order.productName}</h4>
                    <p className="text-white/70 text-sm">Order ID: {order.id}</p>
                    <p className="text-white/50 text-xs">{new Date(order.createdAt).toLocaleDateString('id-ID')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-bold">Rp {order.total.toLocaleString()}</p>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      order.status === 'completed' ? 'bg-green-500/20 text-green-300' : 
                      order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300' :
                      'bg-red-500/20 text-red-300'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default OrdersTab;