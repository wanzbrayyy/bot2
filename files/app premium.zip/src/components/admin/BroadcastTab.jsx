import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';

const BroadcastTab = () => {
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const { addBroadcast } = useStore();

  const handleBroadcast = (e) => {
    e.preventDefault();
    addBroadcast(broadcastMessage);
    setBroadcastMessage('');
  };

  return (
    <Card className="glass-effect border-white/20 bg-white/10 max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <i className="fas fa-bullhorn mr-3"></i>Kirim Broadcast
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleBroadcast} className="space-y-4">
          <textarea
            placeholder="Tulis pesan broadcast untuk semua user..."
            value={broadcastMessage}
            onChange={(e) => setBroadcastMessage(e.target.value)}
            className="w-full p-4 rounded-md bg-white/10 border border-white/20 text-white placeholder:text-white/50 resize-none"
            rows="4"
            required
          />
          <Button type="submit" className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-lg py-3">
            <i className="fas fa-paper-plane mr-2"></i>
            Kirim ke Semua User
          </Button>
        </form>
        <div className="mt-6 p-4 bg-blue-500/20 rounded-lg border border-blue-400/30">
          <div className="flex items-center space-x-3 mb-2">
            <i className="fas fa-info-circle text-blue-300"></i>
            <span className="text-blue-200 font-medium">Info Broadcast</span>
          </div>
          <p className="text-blue-100 text-sm">
            Pesan akan dikirim ke inbox semua user yang terdaftar dan muncul sebagai banner di halaman utama
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default BroadcastTab;