import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useStore } from '@/contexts/StoreContext';
import { toast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const AddProductForm = ({ onAdd }) => {
  const [newProduct, setNewProduct] = useState({
    name: '', description: '', price: '', originalPrice: '',
    category: 'Photography', stock: '', features: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewProduct(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const productData = {
      ...newProduct,
      price: parseInt(newProduct.price),
      originalPrice: newProduct.originalPrice ? parseInt(newProduct.originalPrice) : null,
      stock: parseInt(newProduct.stock),
      features: newProduct.features.split(',').map(f => f.trim()),
      downloadUrl: `/files/${newProduct.name.toLowerCase().replace(/\s+/g, '-')}.apk`
    };
    onAdd(productData);
    setNewProduct({
      name: '', description: '', price: '', originalPrice: '',
      category: 'Photography', stock: '', features: ''
    });
  };

  const handleFileUpload = () => {
    toast({
      title: "🚧 Fitur upload file belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: "Untuk production, integrasikan dengan cloud storage seperti AWS S3",
    });
  };

  return (
    <Card className="glass-effect border-white/20 bg-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <i className="fas fa-plus mr-3"></i>Tambah Produk Baru
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input name="name" placeholder="Nama Produk" value={newProduct.name} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          <textarea name="description" placeholder="Deskripsi Produk" value={newProduct.description} onChange={handleChange} className="w-full p-3 rounded-md bg-white/10 border border-white/20 text-white placeholder:text-white/50 resize-none" rows="3" required />
          <div className="grid grid-cols-2 gap-4">
            <Input name="price" type="number" placeholder="Harga" value={newProduct.price} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
            <Input name="originalPrice" type="number" placeholder="Harga Asli (Opsional)" value={newProduct.originalPrice} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <select name="category" value={newProduct.category} onChange={handleChange} className="p-3 rounded-md bg-white/10 border border-white/20 text-white">
              <option value="Photography">Photography</option>
              <option value="Music">Music</option>
              <option value="Video">Video</option>
              <option value="Productivity">Productivity</option>
              <option value="Games">Games</option>
            </select>
            <Input name="stock" type="number" placeholder="Stock" value={newProduct.stock} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          </div>
          <Input name="features" placeholder="Fitur (pisahkan dengan koma)" value={newProduct.features} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          <div className="flex gap-2">
            <Button type="button" onClick={handleFileUpload} variant="outline" className="border-white/30 text-white hover:bg-white/10">
              <i className="fas fa-upload mr-2"></i>Upload APK
            </Button>
            <Button type="submit" className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500">
              <i className="fas fa-plus mr-2"></i>Tambah Produk
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

const ProductList = ({ products, onDelete }) => (
  <Card className="glass-effect border-white/20 bg-white/10">
    <CardHeader>
      <CardTitle className="text-white flex items-center">
        <i className="fas fa-list mr-3"></i>Daftar Produk
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-4 max-h-96 overflow-y-auto scrollbar-hide">
        {products.map((product) => (
          <div key={product.id} className="glass-effect rounded-lg p-4 border border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="text-white font-semibold">{product.name}</h4>
                <p className="text-white/70 text-sm">Rp {product.price.toLocaleString()}</p>
                <p className="text-white/50 text-xs">Stock: {product.stock}</p>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <i className="fas fa-edit"></i>
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="outline" className="border-red-400/30 text-red-300 hover:bg-red-500/10">
                      <i className="fas fa-trash"></i>
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="glass-effect border-white/20 bg-slate-900 text-white">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
                      <AlertDialogDescription className="text-white/70">
                        Tindakan ini tidak dapat dibatalkan. Ini akan menghapus produk secara permanen.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="text-white">Batal</AlertDialogCancel>
                      <AlertDialogAction onClick={() => onDelete(product.id)} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const ProductTab = () => {
  const { products, addProduct, deleteProduct } = useStore();

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-8">
        <AddProductForm onAdd={addProduct} />
        <ProductList products={products} onDelete={deleteProduct} />
      </div>
    </div>
  );
};

export default ProductTab;