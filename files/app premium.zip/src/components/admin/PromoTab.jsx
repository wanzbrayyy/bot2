import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useStore } from '@/contexts/StoreContext';

const AddPromoForm = ({ onAdd }) => {
  const [newPromo, setNewPromo] = useState({
    code: '', discount: '', type: 'fixed', description: '',
    minPurchase: '', maxUse: '', validUntil: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewPromo(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const promoData = {
      ...newPromo,
      discount: parseInt(newPromo.discount),
      minPurchase: parseInt(newPromo.minPurchase),
      maxUse: parseInt(newPromo.maxUse),
      active: true
    };
    onAdd(promoData);
    setNewPromo({
      code: '', discount: '', type: 'fixed', description: '',
      minPurchase: '', maxUse: '', validUntil: ''
    });
  };

  return (
    <Card className="glass-effect border-white/20 bg-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <i className="fas fa-plus mr-3"></i>Tambah Kode Promo
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input name="code" placeholder="Kode Promo (contoh: WELCOME50)" value={newPromo.code} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          <Input name="description" placeholder="Deskripsi" value={newPromo.description} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          <div className="grid grid-cols-2 gap-4">
            <select name="type" value={newPromo.type} onChange={handleChange} className="p-3 rounded-md bg-white/10 border border-white/20 text-white">
              <option value="fixed">Nominal Tetap</option>
              <option value="percentage">Persentase</option>
            </select>
            <Input name="discount" type="number" placeholder={newPromo.type === 'percentage' ? 'Diskon (%)' : 'Diskon (Rp)'} value={newPromo.discount} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input name="minPurchase" type="number" placeholder="Min. Pembelian" value={newPromo.minPurchase} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
            <Input name="maxUse" type="number" placeholder="Max. Penggunaan" value={newPromo.maxUse} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-white/50" required />
          </div>
          <Input name="validUntil" type="date" value={newPromo.validUntil} onChange={handleChange} className="bg-white/10 border-white/20 text-white" required />
          <Button type="submit" className="w-full bg-gradient-to-r from-purple-500 to-pink-500">
            <i className="fas fa-plus mr-2"></i>Tambah Promo
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

const PromoList = ({ promoCodes }) => (
  <Card className="glass-effect border-white/20 bg-white/10">
    <CardHeader>
      <CardTitle className="text-white flex items-center">
        <i className="fas fa-list mr-3"></i>Daftar Promo
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-4 max-h-96 overflow-y-auto scrollbar-hide">
        {promoCodes.map((promo) => (
          <div key={promo.id} className="glass-effect rounded-lg p-4 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-white font-bold text-lg">{promo.code}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${promo.active ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                {promo.active ? 'Aktif' : 'Nonaktif'}
              </span>
            </div>
            <p className="text-white/70 text-sm mb-2">{promo.description}</p>
            <div className="flex justify-between text-xs text-white/50">
              <span>Digunakan: {promo.used}/{promo.maxUse}</span>
              <span>Berlaku hingga: {new Date(promo.validUntil).toLocaleDateString('id-ID')}</span>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const PromoTab = () => {
  const { promoCodes, addPromoCode } = useStore();

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-8">
        <AddPromoForm onAdd={addPromoCode} />
        <PromoList promoCodes={promoCodes} />
      </div>
    </div>
  );
};

export default PromoTab;