import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { useStore } from '@/contexts/StoreContext';

const StatCard = ({ icon, title, value, gradient }) => (
  <Card className="glass-effect border-white/20 bg-white/10">
    <CardContent className="p-6 text-center">
      <div className={`w-16 h-16 ${gradient} rounded-full flex items-center justify-center mx-auto mb-4`}>
        <i className={`fas ${icon} text-white text-2xl`}></i>
      </div>
      <h3 className="text-2xl font-bold text-white mb-2">{value}</h3>
      <p className="text-white/70">{title}</p>
    </CardContent>
  </Card>
);

const AdminStats = () => {
  const { products, promoCodes, orders } = useStore();

  const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0).toLocaleString();

  const stats = [
    { icon: 'fa-box', title: 'Total Produk', value: products.length, gradient: 'bg-gradient-to-r from-purple-500 to-pink-500' },
    { icon: 'fa-shopping-cart', title: 'Total Pesanan', value: orders.length, gradient: 'bg-gradient-to-r from-green-500 to-blue-500' },
    { icon: 'fa-tag', title: 'Kode Promo', value: promoCodes.length, gradient: 'bg-gradient-to-r from-yellow-500 to-orange-500' },
    { icon: 'fa-dollar-sign', title: 'Total Pendapatan', value: `Rp ${totalRevenue}`, gradient: 'bg-gradient-to-r from-red-500 to-pink-500' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="grid md:grid-cols-4 gap-6 mb-8"
    >
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </motion.div>
  );
};

export default AdminStats;