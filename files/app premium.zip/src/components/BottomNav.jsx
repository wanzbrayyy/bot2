import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, ShoppingBag, User, Settings } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const BottomNav = () => {
  const { user } = useAuth();

  const navItems = [
    { path: '/', icon: <Home />, label: 'Beranda' },
    { path: '/store', icon: <ShoppingBag />, label: 'Store' },
    { path: user ? (user.role === 'admin' ? '/admin' : '/dashboard') : '/login', icon: <User />, label: 'Akun' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 glass-effect border-t border-white/10 md:hidden z-50">
      <div className="flex justify-around items-center h-full">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center space-y-1 transition-colors duration-300 ${
                isActive ? 'text-purple-400' : 'text-white/70 hover:text-white'
              }`
            }
          >
            {item.icon}
            <span className="text-xs font-medium">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;